require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const User = require('./server/models/User');
const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CLIENT_ORIGIN || true }));
app.use(express.json({ limit: '20kb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/auth', require('./server/routes/auth'));
app.use('/api', require('./server/routes/api'));
app.use(express.static(path.join(__dirname)));
app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'MessMeter API' }));
app.use((req, res) => res.status(404).json({ message: 'Requested resource was not found.' }));
app.use((err, _req, res, _next) => {
  console.error(err);
  if (err.code === 11000) return res.status(409).json({ message: 'Email or student ID already exists.' });
  if (err.name === 'ValidationError' || err.name === 'CastError') return res.status(400).json({ message: 'Submitted data is invalid.' });
  res.status(500).json({ message: 'Unexpected server error. Please try again.' });
});
async function start() {
  if (!process.env.MONGODB_URI || !process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error('Set MONGODB_URI and a JWT_SECRET of at least 32 characters in .env.');
  await mongoose.connect(process.env.MONGODB_URI);
  if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
    const email = process.env.ADMIN_EMAIL.toLowerCase();
    const existing = await User.findOne({ email });
    if (!existing) await User.create({ name: process.env.ADMIN_NAME || 'MessMeter Admin', email, passwordHash: await bcrypt.hash(process.env.ADMIN_PASSWORD, 12), role: 'admin' });
  }
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`MessMeter running at http://localhost:${port}`));
}
if (require.main === module) start().catch(err => { console.error(err.message); process.exit(1); });
module.exports = app;
