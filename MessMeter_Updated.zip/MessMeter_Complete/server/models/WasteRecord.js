const mongoose = require('mongoose');
module.exports = mongoose.model('WasteRecord', new mongoose.Schema({
  date: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ },
  kg: { type: Number, required: true, min: 0, max: 100000 },
  note: { type: String, trim: true, maxlength: 300 },
  recordedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true }));
