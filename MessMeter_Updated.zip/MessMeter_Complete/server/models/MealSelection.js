const mongoose = require('mongoose');
module.exports = mongoose.model('MealSelection', new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  meals: [{ type: String, enum: ['Breakfast', 'Lunch', 'Snacks', 'Dinner'] }],
  serviceAt: { type: Date, required: true, index: true }
}, { timestamps: true }));
