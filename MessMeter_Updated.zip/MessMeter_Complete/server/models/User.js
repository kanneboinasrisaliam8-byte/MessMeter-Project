const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  studentId: { type: String, trim: true, sparse: true, unique: true },
  email: { type: String, required: true, trim: true, lowercase: true, unique: true, maxlength: 160 },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ['student', 'admin'], default: 'student' }
}, { timestamps: true });
module.exports = mongoose.model('User', userSchema);
