const MEALS = ['Breakfast', 'Lunch', 'Snacks', 'Dinner'];
function isCutoffPassed(serviceAt, now = new Date(), cutoffHours = 6) {
  const service = new Date(serviceAt);
  if (Number.isNaN(service.getTime())) throw new Error('Invalid service date');
  return now.getTime() > service.getTime() - Number(cutoffHours) * 60 * 60 * 1000;
}
function calculateHeadcount(totalStudents, optedOutCount) {
  const total = Number(totalStudents), optedOut = Number(optedOutCount);
  if (!Number.isInteger(total) || total < 0 || !Number.isInteger(optedOut) || optedOut < 0 || optedOut > total) {
    throw new Error('Total students and opt-outs must be valid whole numbers, and opt-outs cannot exceed total students.');
  }
  return total - optedOut;
}
module.exports = { MEALS, isCutoffPassed, calculateHeadcount };
