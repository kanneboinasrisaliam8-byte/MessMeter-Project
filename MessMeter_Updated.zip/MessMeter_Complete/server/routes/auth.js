const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
function tokenFor(user) { return jwt.sign({ sub: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '1d' }); }
function publicUser(user) { return { id: user._id, name: user.name, email: user.email, role: user.role, studentId: user.studentId || null }; }
router.post('/register', async (req, res, next) => {
  try {
    const { name, studentId, email, password } = req.body;
    if (!name || !studentId || !email || typeof password !== 'string' || password.length < 8) return res.status(400).json({ message: 'Name, student ID, email and a password of at least 8 characters are required.' });
    const existing = await User.findOne({ $or: [{ email: String(email).toLowerCase() }, { studentId: String(studentId) }] });
    if (existing) return res.status(409).json({ message: 'An account with this email or student ID already exists. Please log in.' });
    const user = await User.create({ name, studentId, email, passwordHash: await bcrypt.hash(password, 12), role: 'student' });
    res.status(201).json({ token: tokenFor(user), user: publicUser(user) });
  } catch (e) { next(e); }
});
router.post('/login', async (req, res, next) => {
  try {
    const { email, password, role } = req.body;
    if (!email || !password || !['student', 'admin'].includes(role)) return res.status(400).json({ message: 'Email, password and valid account role are required.' });
    const user = await User.findOne({ email: String(email).toLowerCase() });
    if (!user || user.role !== role || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ message: 'Invalid email, password or account type.' });
    res.json({ token: tokenFor(user), user: publicUser(user) });
  } catch (e) { next(e); }
});
module.exports = router;
