const { calculateHeadcount, isCutoffPassed } = require('../server/utils/mealRules');
describe('MessMeter meal rules', () => {
  test('calculates expected headcount from enrolled students and opt-outs', () => expect(calculateHeadcount(50, 15)).toBe(35));
  test('allows zero opt-outs', () => expect(calculateHeadcount(30, 0)).toBe(30));
  test('rejects opt-outs greater than total students', () => expect(() => calculateHeadcount(10, 11)).toThrow());
  test('rejects negative or fractional counts', () => { expect(() => calculateHeadcount(-1, 0)).toThrow(); expect(() => calculateHeadcount(10, 1.5)).toThrow(); });
  test('closes meal selection six hours before service', () => {
    const service = new Date('2026-12-01T12:00:00Z');
    expect(isCutoffPassed(service, new Date('2026-12-01T05:59:00Z'), 6)).toBe(false);
    expect(isCutoffPassed(service, new Date('2026-12-01T06:01:00Z'), 6)).toBe(true);
  });
});
